
		var canvas = d3.select("body").append("svg")
			.attr("width",800)
			.attr("height",500);
var mdata;
d3.json("mydata.json", 
	//call back func - all the code wil be loaded once our data will load
	function(error, mydata){
		
		if(error) throw error;
		
		mdata = mydata;
		
	canvas.selectAll("rect")//selectAll select the empty DOM elem 
			.data(mdata) //this method bound the empty selection to the data
			.enter() //this method return placeholder foreach data elem where there is no DOM elem. 
				.append("rect")
				.attr("width", function(d){ // attr("property_name",value/function)
						return d.age * 10;
					}				
				)
				.attr("height",50)
				.attr("y", function(d,i){
					return i * 55;
				})
				.attr("fill","blue");	
				
					canvas.selectAll("text")
			.data(mdata)
			.enter()
				.append("text")
				.attr("fill","white")
				.attr("y", function(d,i){
					return i * 110;
				})
				.text(function(d){
					return d.name;
				});		
	}
);


				


		

