var data = [10,20];

var canvas = d3.select("body")
				.append("svg")
				.attr("width",900)
				.attr("height",900)
				
				
var circle = canvas.append("circle")
					.attr("cx",50)
					.attr("cy",100)
					.attr("r",25)
					.attr("fill","red");


		
var circle = canvas.append("circle")
					.attr("cx",50)
					.attr("cy",200)
					.attr("r",25);

var circle = canvas.append("circle")
					.attr("cx",50)
					.attr("cy",300)
					.attr("r",25);


					
var circles = canvas.selectAll("circle")
					.data(data)
					.attr("fill","green")//update the all the data with red 
		/*			.enter()
					.append("circle")
					.attr("cx",50)
					.attr("cy",200)					
					.attr("r",25)
					.attr("fill","green");//fill this circle with green; 
		*/
					.exit()
					.attr("fill","blue");

var tcircle = canvas.selectAll("circle")					
	
	tcircle.transition()
		//.duration(2500)
		.delay(3500)
		.attr("cx",200)
		.each("end",function(){ //end,start, this function will run after the transition
					d3.select(this).attr("fill","red");
				}
			);