if (window.TimesPeople && TimesPeople.URIList && TimesPeople.URIList.allowsCurrentPage()) {
    NYTD.require('/js2/build/timespeople/build.js');
}
