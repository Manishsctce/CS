var NYTD = window.NYTD || {};
NYTD.env = "production";

